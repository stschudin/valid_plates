/pwa-license-plate
│
├── index.html         # Hauptseite
├── script.js          # JavaScript-Logik
├── style.css          # Styling
├── valid_plates.json  # Liste erlaubter Kennzeichen
├── manifest.json      # PWA-Konfiguration
└── service-worker.js  # Service Worker für PWA-Funktionalität
